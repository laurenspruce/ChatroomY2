package chatroomserver.models;

public class UserModel {
 
    public String username;
    public String password;

    public UserModel(String username, String password) {
        this.username = username;
        this.password = password;
    }
    
}
