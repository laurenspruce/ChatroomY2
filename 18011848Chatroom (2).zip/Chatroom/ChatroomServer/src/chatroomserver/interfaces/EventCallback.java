package chatroomserver.interfaces;

public interface EventCallback {
    void onMessageReceived(String message);
}
