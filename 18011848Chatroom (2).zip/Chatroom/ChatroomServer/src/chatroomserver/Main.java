package chatroomserver;

import chatroomserver.ui.MainWindow;

public class Main {
    public static void main(String[] args) {
        MainWindow.init();
    }
}
