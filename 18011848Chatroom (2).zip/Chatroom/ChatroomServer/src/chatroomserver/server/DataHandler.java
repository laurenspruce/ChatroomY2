package chatroomserver.server;

import chatroomserver.ChatroomServer;
import java.io.BufferedOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;

//Handles data connection
public class DataHandler implements Runnable {

    //Parameter
    public String username;
    
    //Connection socket and streams
    public Socket userSocket;
    private final InputStream inputStream;
    public PrintWriter printOutputStream;
    
    private boolean running = true;
    
    public DataHandler(String username, Socket socket) throws IOException {
        this.userSocket = socket;
        this.username = username;
        
        this.inputStream = socket.getInputStream();
        this.printOutputStream = new PrintWriter(new BufferedOutputStream(socket.getOutputStream()));
    }
    
    @Override
    public void run() {
        try {
            //Start main data loop
            while(userSocket.isConnected() && running){

                //available commands to data socket
                String command = readLine(inputStream);

                if(command.startsWith("message-chatroom")) {
                    String[] arguments = command.split(" ");
                    String chatroomName = arguments[1].substring(0, arguments[1].length());
                    String finalMessage = readMessage();

                    //Send message to chatroom
                    HashMap<String, Chatroom> chatrooms = ChatroomServer.chatrooms;
                    if(chatrooms.containsKey(chatroomName)) {
                        Chatroom chatroom = chatrooms.get(chatroomName);
                        chatroom.send(username, finalMessage);
                    }
                }else if(command.startsWith("message-user")) {
                    String[] arguments = command.split(" ");
                    String to = arguments[1];
                    String finalMessage = readMessage();
                    
                    //Send message to user
                    if(ChatroomServer.onlineUsers.containsKey(username)) {
                        ChatroomServer.onlineUsers.get(to)
                                .sendMessageFrom(username, "", finalMessage);
                    }
                }else if(command.startsWith("file-user")) {
                    String[] arguments = command.split(" ");
                    String username = arguments[1];
                    
                    //If the user exists
                    if(ChatroomServer.onlineUsers.containsKey(username)) {
                        User to = ChatroomServer.onlineUsers.get(username);
                        String filename = readLine(inputStream);
                        long filesize = Long.parseLong(readLine(inputStream));
                        
                        //Relay the stream from the "sending user" to the "destination user"
                        //"destination user" = to.dataOutputStream
                        //"sending user" = userSocket.getInputStream()
                        new FileTransfer(to.dataOutputStream, 
                                filename,
                                filesize,
                                userSocket.getInputStream()).start();
                    }
                }else if(command.startsWith("file-chatroom")) {
                    String[] arguments = command.split(" ");
                    String chatroomName = arguments[1];
                    
                    //Send message to chatroom
                    HashMap<String, Chatroom> chatrooms = ChatroomServer.chatrooms;
                    if(chatrooms.containsKey(chatroomName)) {
                        Chatroom chatroom = chatrooms.get(chatroomName);
                        
                        String filename = readLine(inputStream);
                        long filesize = Long.parseLong(readLine(inputStream));
                        
                        //Relay input stream from the "sending user" to the chatroom
                        //"sending user" = userSocket.getInputStream()
                        chatroom.sendFile(username, filename, filesize, userSocket.getInputStream());
                    }
                }

            }
        } catch (IOException ex) {
            Logger.getLogger(User.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    
    
    //Read a string from the input stream until \nEND\n
    private String readMessage() throws IOException {
        StringBuilder message = new StringBuilder();
        int lastByte = 0;
        while((lastByte = userSocket.getInputStream().read()) != -1) {
            char c = ((char) lastByte);
            message.append(c);

            if(message.lastIndexOf("\nEND\n") >= 0) break;
        }

        String finalMessage = message.toString();
        return finalMessage.substring(0, finalMessage.length() - 5);
    }
    
    //Read a line from the given InputStream
    public static String readLine(InputStream inputStream) throws IOException {
        StringBuilder filename = new StringBuilder();
        int lastByte = 0;
        while((lastByte = inputStream.read()) != -1) {
            char c = ((char) lastByte);
            if(c == '\n') break;
            filename.append(c);
        }
        
        return filename.toString();
    }
    
}
