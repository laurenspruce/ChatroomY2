package chatroomserver.server;

import chatroomserver.ChatroomServer;
import java.util.ArrayList;
import chatroomserver.interfaces.EventCallback;
import java.io.IOException;
import java.io.InputStream;
import java.util.logging.Level;
import java.util.logging.Logger;
import chatroomserver.utils.*;

public class Chatroom {
    
    public String chatroomName;
    public ArrayList<User> participants = new ArrayList<>();
    public EventCallback eventCallback;

    public Chatroom(String chatroomName) {
        this.chatroomName = chatroomName;
    }
    
    public void join(User user) {
        participants.add(user);
    }
    
    public void remove(User user) {
        participants.remove(user);
    }
    
    public void send(String from, String message) {
        
        //Notify the message has been sent
        if(eventCallback != null) {
            eventCallback.onMessageReceived("[" + chatroomName + "] " + from + ": " + message);
        }
        
        //Send a message to each chatroom participant
        participants.stream()
                .filter(user -> !user.username.equals(from))
                .forEach(user -> {
            try {
                user.sendMessageFrom(from, "[" + chatroomName + "] ", message);
            } catch (IOException ex) {
                Logger.getLogger(Chatroom.class.getName()).log(Level.SEVERE, null, ex);
            }
        });
    }
    
    public void sendFile(String from, String filename, long fileSize, InputStream file) {
        //Send file to each chatroom participant
        participants.stream()
                .filter(user -> !user.username.equals(from))
                .forEach(user -> {
                    new FileTransfer(user.dataOutputStream, filename, fileSize, file).start();
                });
    }
    
    public void sendAsServer(ChatroomServer server, String message) {
        //Notify the message has been sent
        if(eventCallback != null) {
            eventCallback.onMessageReceived("[" + chatroomName + "] SERVER: " + message);
        }
        
        //Send a message to each chatroom participant
        participants.stream()
                .forEach(user -> {
            try {
                server.sendMessageTo(user, "[" + chatroomName + "] ", message);
            } catch (IOException ex) {
                Logger.getLogger(Chatroom.class.getName()).log(Level.SEVERE, null, ex);
            }
        });
    }
    
    public void sendFileAsServer(ChatroomServer server, String filename, long fileSize, SplittableInputStream file) {
        sendAsServer(server, "file sent");
        participants.stream()
                .forEach(user -> {
                    new FileTransfer(user.dataOutputStream, filename, fileSize, file.split()).start();
                });
    }
    
    @Override
    public String toString() {
        return this.chatroomName;
    }
    
}
