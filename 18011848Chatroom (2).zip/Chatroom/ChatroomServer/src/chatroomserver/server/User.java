package chatroomserver.server;

import chatroomserver.models.UserModel;
import chatroomserver.ChatroomServer;
import chatroomserver.interfaces.EventCallback;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;

//Handles the user command connection
public class User implements Runnable {
    
    //Parameters
    public String username;
    private String password;
   
    //Socket and streams
    public Socket userSocket;
    private BufferedReader inputStream;
    public PrintWriter printOutputStream;
    
    //User data I/O streams
    public InputStream dataInputStream;
    public OutputStream dataOutputStream;
    
    private boolean running = true;
    private EventCallback eventCallback;
    
    public User(Socket socket, EventCallback eventCallback) throws IOException {
        this.userSocket = socket;
        this.eventCallback = eventCallback;
        
        this.inputStream = new BufferedReader(new InputStreamReader(socket.getInputStream()));
        this.printOutputStream = new PrintWriter(new BufferedOutputStream(socket.getOutputStream()));
    }
    
    @Override
    public void run() {
        try {
            //Start login/register process
            boolean success = false;
            while(!success && userSocket.isConnected()) {
                String action = inputStream.readLine();
                if(action.equals("login")) success = handleLogin();
                else success = handleRegister();
            }

            //Join the user to default chatroom
            if(userSocket.isConnected()){
                ChatroomServer.chatrooms.get("#general").join(this);
            }
            
            if(eventCallback != null)
                eventCallback.onMessageReceived(username + " has connected!");

            //Start main user loop
            while(userSocket.isConnected() && running){

                //available commands to socket
                String command = inputStream.readLine();

                if(command.equals("list users")) {
                    //Send list of online users
                    for(String user : ChatroomServer.onlineUsers.keySet()) 
                        printOutputStream.print(user + "\n");

                    printOutputStream.print("OK\n");
                    printOutputStream.flush();
                }else if(command.startsWith("list chatrooms")){
                    //Send list of chatrooms where user is in
                    for(Chatroom chatroom : ChatroomServer.chatrooms.values()) {
                        if(chatroom.participants.stream().anyMatch(user -> user.username.equals(username)))
                            printOutputStream.print(chatroom.toString() + "\n");   
                    }

                    printOutputStream.print("OK\n");
                    printOutputStream.flush();
                }else if(command.startsWith("create chatroom")){
                    String[] arguments = command.split(" ");
                    String chatroomName = arguments[2];
                    
                    if(ChatroomServer.chatrooms.containsKey(chatroomName)) {
                        printOutputStream.print("Chatroom already exist\n");
                    }else {
                        Chatroom chatroom = new Chatroom(chatroomName);
                        chatroom.eventCallback = eventCallback;
                        
                        //Create new chatroom
                        ChatroomServer.chatrooms.put(chatroomName, chatroom);
                        chatroom.join(this);
                        
                        //Send acknowledgment
                        printOutputStream.print("OK\n");
                    }
                    
                    printOutputStream.flush();
                }else if(command.startsWith("join chatroom")){
                    String[] arguments = command.split(" ");
                    String chatroomName = arguments[2];
                    
                    if(!ChatroomServer.chatrooms.containsKey(chatroomName)) {
                        printOutputStream.print("Chatroom doesn't exist\n");
                    }else {
                        //Add user to the chatroom
                        ChatroomServer.chatrooms.get(chatroomName).join(this);
                        
                        //Send acknowledgment
                        printOutputStream.print("OK\n");
                    }
                    
                    printOutputStream.flush();
                }else if(command.equals("stop")) {
                    running = false;
                }

            }
        } catch (IOException ex) {
            Logger.getLogger(User.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
        stop();
    }
    
    @Override
    public String toString() {
        return username + " " + userSocket.getInetAddress().getHostAddress();
    }
    
    public void sendMessageFrom(String from, String prefix, String message) throws IOException {
        dataOutputStream.write("message\n".getBytes());
        String finalMessage = prefix + from + ": " + message;
        dataOutputStream.write(finalMessage.getBytes());
        dataOutputStream.write("\nEND\n".getBytes());
    }
    
    public void stop() {
        
        //Remove user from chatrooms and online users
        ChatroomServer.onlineUsers.remove(username);
        ChatroomServer.chatrooms.values().stream()
                .filter(chatroom -> chatroom.participants.contains(this))
                .forEachOrdered(chatroom -> chatroom.remove(this));
        
        //Send notification
        if(eventCallback != null)
                eventCallback.onMessageReceived(username + " disconnected!");
        
        //Close connections
        try {
            printOutputStream.close();
            inputStream.close();
            userSocket.close();
        } catch (IOException ex) {
            Logger.getLogger(User.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    
    private boolean handleLogin() throws IOException {
        username = inputStream.readLine();
        password = inputStream.readLine();
        
        //Check username and password
        boolean hasUser = ChatroomServer.hasUser(new UserModel(username, password));
        if(!hasUser) printOutputStream.print("Username or password wrong!\n");
        else {
            ChatroomServer.onlineUsers.put(username, this);
            printOutputStream.print("OK\n");
        }
        
        printOutputStream.flush();
        return hasUser;
    }
    
     private boolean handleRegister() throws IOException {
        username = inputStream.readLine();
        password = inputStream.readLine();
        
        //Check username and password
        boolean hasUsername = ChatroomServer.hasUsername(username);
        if(hasUsername) printOutputStream.print("Username is already taken!\n");
        else {
            ChatroomServer.registeredUsers.add(new UserModel(username, password));
            printOutputStream.print("OK\n");
        }
        
        printOutputStream.flush();
        return !hasUsername;
    }
}
