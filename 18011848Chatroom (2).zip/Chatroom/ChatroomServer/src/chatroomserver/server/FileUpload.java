package chatroomserver.server;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.logging.Level;
import java.util.logging.Logger;

public class FileUpload extends Thread {
    
    private final File file;
    private final User to;

    public FileUpload(User to, File file) {
        this.to = to;
        this.file = file;
    }
    
    @Override
    public void run() {
        try {
            FileInputStream fis = new FileInputStream(file);
            BufferedInputStream bis = new BufferedInputStream(fis);
            long fileLength = file.length();

            //Get socket's data output stream
            OutputStream os = to.dataOutputStream;
            
            //Send "file" data type
            os.write("file\n".getBytes());
            
            //Send filename and filesize
            os.write((file.getName() + "\n").getBytes());
            os.write((fileLength + "\n").getBytes());
            os.flush();

            //Read File Contents into contents array
            byte[] contents;
            long current = 0;

            while(current != fileLength){
                int size = 10240;
                if(fileLength - current >= size)
                    current += size;
                else{
                    size = (int)(fileLength - current);
                    current = fileLength;
                }
                contents = new byte[size];
                
                //Read from file and send to user data output stream
                bis.read(contents, 0, size);
                os.write(contents);
            }

            os.flush();
            bis.close();
        } catch (IOException ex) {
            Logger.getLogger(User.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
