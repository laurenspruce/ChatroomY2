package chatroomserver.server;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.logging.Level;
import java.util.logging.Logger;


//Relay one stream to a another one
public class FileTransfer {
    
    private final InputStream file;
    private final OutputStream to;
    private final String filename;
    private final long fileSize;

    public FileTransfer(OutputStream dest, String filename, long fileSize, InputStream file) {
        this.to = dest;
        this.filename = filename;
        this.file = file;
        this.fileSize = fileSize;
    }
    
    public void start() {
        try {
            BufferedInputStream bis = new BufferedInputStream(file);

            //Send "file" data type
            to.write("file\n".getBytes());
            
            //Send filename and filesize
            to.write((filename + "\n").getBytes());
            to.write((fileSize + "\n").getBytes());
            
            //Relay stream
            byte[] contents;
            long current = 0;
            int bytesRead = 0;

            while(current < fileSize){
                int size = 10240;
                if(fileSize - current >= size)
                    current += size;
                else{
                    size = (int)(fileSize - current);
                    current = fileSize;
                }
                
                contents = new byte[size];
                
                //Read from one stream and send to the other one
                bytesRead = bis.read(contents, 0, size);
                to.write(contents, 0, bytesRead);
            }
            
            to.flush();
        } catch (IOException ex) {
            Logger.getLogger(FileTransfer.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
