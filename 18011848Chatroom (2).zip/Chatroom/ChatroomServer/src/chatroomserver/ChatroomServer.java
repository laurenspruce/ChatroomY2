package chatroomserver;

import chatroomserver.server.Chatroom;
import chatroomserver.server.User;
import chatroomserver.models.UserModel;
import java.io.File;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import chatroomserver.interfaces.EventCallback;
import chatroomserver.server.DataHandler;
import chatroomserver.server.FileUpload;
import java.io.BufferedReader;
import java.io.InputStreamReader;

public class ChatroomServer {
    //List of chatrooms
    public static volatile HashMap<String, Chatroom> chatrooms = new HashMap<>();
    
    //List of online and registered users
    public static volatile HashMap<String, User> onlineUsers = new HashMap<>();
    public static volatile ArrayList<UserModel> registeredUsers = new ArrayList<>();
    
    public static boolean hasUser(UserModel user) {
        return registeredUsers.stream().anyMatch(
                usr -> usr.username.equals(user.username)
                        && usr.password.equals(user.password));
    }
    
    public static boolean hasUsername(String username) {
        return registeredUsers.stream().anyMatch(user -> user.username.equals(username));
    }
    
    private ServerSocket commandServerSocket;
    private ServerSocket dataServerSocket;
    
    private EventCallback eventCallback;
    
    //Thread pool where clients are handled
    private ExecutorService clients;
    private boolean running = false;
    
    public ChatroomServer(EventCallback eventCallback) throws IOException {
        this.eventCallback = eventCallback;
        
        //Create the default chatroom
        String chatroomName = "#general";
        Chatroom chatroom = new Chatroom(chatroomName);
        chatrooms.put(chatroomName, chatroom);
        chatroom.eventCallback = eventCallback;
        
        //Create the default users
        registeredUsers.add(new UserModel("Lauren", "pass1"));
        registeredUsers.add(new UserModel("Charlie", "pass2"));
        registeredUsers.add(new UserModel("Bailey", "pass3"));
        registeredUsers.add(new UserModel("Cooper", "pass4"));
    }
    
    
    public void start() throws IOException {
        //Init servers
        this.commandServerSocket = new ServerSocket(7777);
        this.dataServerSocket = new ServerSocket(7778);
        
        //Create threadpool
        clients = Executors.newCachedThreadPool();
        
        //Start handling clients (command connection)
        Thread handlingControlThread = new Thread(() -> {
            
            Socket client;
            while(running && !commandServerSocket.isClosed()) {
                try {
                    //Accept a new client
                    client = commandServerSocket.accept();
                    clients.submit(new User(client, eventCallback));
                } catch (IOException ex) {
                    break;
                }
            }
        });
        
        //Start handling clients (data connection)
        Thread handlingDataThread = new Thread(() -> {
            
            Socket client;
            while(running && !dataServerSocket.isClosed()) {
                try {
                    //Accept a new client
                    client = dataServerSocket.accept();
                    BufferedReader reader = new BufferedReader(
                            new InputStreamReader(client.getInputStream()));
                    
                    //Wait for the client username
                    String user = reader.readLine();
                    reader = null;
                    
                    //Set data input streams to the client
                    onlineUsers.get(user)
                            .dataInputStream = client.getInputStream();
                    
                    onlineUsers.get(user)
                            .dataOutputStream = client.getOutputStream();
                    
                    clients.submit(new DataHandler(user, client));
                } catch (IOException ex) {
                    break;
                }
            }
        });
        
        running = true;
        
        //Start handling
        handlingControlThread.start();
        handlingDataThread.start();
    }
    
    
    public void sendMessageTo(User user, String prefix, String message) throws IOException {
        user.dataOutputStream.write("message\n".getBytes());
        String finalMessage = prefix + "SERVER: " + message;
        user.dataOutputStream.write(finalMessage.getBytes());
        user.dataOutputStream.write("\nEND\n".getBytes());
        user.dataOutputStream.flush();
    }
    
    public void sendFileTo(User to, File file) throws IOException {
        sendMessageTo(to, "", "Sending file " + file.getName());
        new FileUpload(to, file).start();
    }
    
    
    public void stop() throws IOException {
        running = false;
        
        clients.shutdownNow();
        onlineUsers.forEach((username, client) -> client.stop());
        commandServerSocket.close();
        dataServerSocket.close();
    }
    
    
}
