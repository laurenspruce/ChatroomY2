package chatroomclient;

import java.io.File;

public class Config {
    public static final String DIRPATH = System.getProperty("user.home") + File.separator;
}
