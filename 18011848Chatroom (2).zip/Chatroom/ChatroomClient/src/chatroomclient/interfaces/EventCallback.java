package chatroomclient.interfaces;

public interface EventCallback {
    void onMessageReceived(String message);
    void onFileReceived(String filename);
    void fileUploadProgress(double progress);
}
