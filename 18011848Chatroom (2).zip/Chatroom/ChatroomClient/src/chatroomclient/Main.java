package chatroomclient;

import chatroomclient.ui.LoginRegisterWindow;

public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        ChatroomServer.init("localhost", 7777);
        LoginRegisterWindow.init();
    }
    
}
