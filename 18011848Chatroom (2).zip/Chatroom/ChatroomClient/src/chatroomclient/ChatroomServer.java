package chatroomclient;

import chatroomclient.client.FileHandler;
import chatroomclient.client.FileUpload;
import chatroomclient.client.MessageHandler;
import chatroomclient.interfaces.EventCallback;
import chatroomclient.models.Chatroom;
import chatroomclient.models.UserModel;
import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ChatroomServer {
    
    //Command connection
    public Socket server;
    
    //Data connection
    public Socket dataConnection;
    
    //Command streams
    public BufferedReader inputStream;
    public PrintWriter printOutputStream;
    
    //Parameters
    private final String host;
    private final int port;
    private boolean running = true;
    
    //Singleton instance
    private static ChatroomServer _chatroomServer;
    
    
    private EventCallback eventCallback;
    public void addEventCallback(EventCallback eventCallback) {
        this.eventCallback = eventCallback;
    }
    
    private Thread handlingMessageThread;
    
    //Username for the individual
    private String username;
    public void setUsername(String username) {
        this.username = username;
    }
    
    //Connect to the server
    public static void init(String host, int port) {
        try {
            _chatroomServer = new ChatroomServer(host, port);
            _chatroomServer.connect();
        } catch (IOException ex) {
            Logger.getLogger(ChatroomServer.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    //Returns the singleton instance
    public static ChatroomServer get() {
        return _chatroomServer;
    }
    
    //Private constructor
    private ChatroomServer(String host, int port) throws IOException {
        this.host = host;
        this.port = port;
    }
    
    //Init a connection to the server (command)
    public void connect() throws IOException {
        server = new Socket(host, port);

        this.inputStream = new BufferedReader(new InputStreamReader(server.getInputStream()));
        this.printOutputStream = new PrintWriter(server.getOutputStream());
    }
    
    //Init a connection to the server (data)
    public void startReceiving(String username) throws IOException {
        dataConnection = new Socket(host, port + 1);
        
        //Start handling incoming messages and files
        running = true;
        handlingMessageThread = new Thread(() -> {
            String type = "";
            
            try {
                dataConnection.getOutputStream().write((username + "\n").getBytes());
            } catch (IOException ex) {
                Logger.getLogger(ChatroomServer.class.getName()).log(Level.SEVERE, null, ex);
            }
            
            while(running) {
                try {
                    //Read data type (either message or file)
                    type = readLine(dataConnection.getInputStream());
                    
                    if(type.equals("message")) {
                        new MessageHandler(dataConnection.getInputStream(), eventCallback).start();
                    }else if(type.equals("file")){
                        new FileHandler(dataConnection.getInputStream(), Config.DIRPATH, eventCallback).start();
                    }
                } catch (IOException ex) {
                    Logger.getLogger(ChatroomServer.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });
        
        handlingMessageThread.start();
    }
    
    //Return a list of online users
    public ArrayList<UserModel> getOnlineUsers() throws IOException {
        printOutputStream.print("list users\n");
        printOutputStream.flush();
        ArrayList<UserModel> users = new ArrayList();
        
        String user = inputStream.readLine();
        while(!user.equals("OK")) {
            users.add(new UserModel(user));
            user =  inputStream.readLine();
        }
        
        return users;
    }
    
    //Return a list of chatrooms the user is in
    public ArrayList<Chatroom> getChatrooms() throws IOException {
        printOutputStream.print("list chatrooms\n");
        printOutputStream.flush();
        ArrayList<Chatroom> chatrooms = new ArrayList();

        String chatroomName = inputStream.readLine();
        while(!chatroomName.equals("OK")) {
            chatrooms.add(new Chatroom(chatroomName));
            chatroomName = inputStream.readLine();
        }

        return chatrooms;
    }
     
    public void sendMessageToChatroom(Chatroom chatroom, String message) throws IOException {
        OutputStream out = dataConnection.getOutputStream();
        out.write(("message-chatroom " + chatroom.chatroomName + "\n").getBytes());
        out.write(message.getBytes());
        out.write("\nEND\n".getBytes());
        out.flush();
    }
    
    public void sendFileToChatroom(Chatroom chatroom, File file) throws IOException {
        sendMessageToChatroom(chatroom, "file sent!");
        new FileUpload(dataConnection, file, eventCallback)
                .withCommand("file-chatroom " + chatroom.chatroomName)
                .start();
    }
    
    public void sendMessageToUser(UserModel user, String message) throws IOException {
        if(eventCallback != null && !user.username.equals(username)) eventCallback.onMessageReceived(username + ": " + message);
        OutputStream out = dataConnection.getOutputStream();
        out.write(("message-user " + user.username + "\n").getBytes());
        out.write(message.getBytes());
        out.write("\nEND\n".getBytes());
        out.flush();
    }
    
    public void sendFileToUser(UserModel user, File file) throws IOException {
        sendMessageToUser(user, "File sent!");
        new FileUpload(dataConnection, file, eventCallback)
                .withCommand("file-user " + user.username)
                .start();
    }
    
    public String createChatroom(String chatroomName) throws IOException {
        printOutputStream.print("create chatroom " + chatroomName + "\n");
        printOutputStream.flush();
        
        return inputStream.readLine();
    }
    
    public String joinChatroom(String chatroomName) throws IOException {
        printOutputStream.print("join chatroom " + chatroomName + "\n");
        printOutputStream.flush();
        
        return inputStream.readLine();
    }
    
    public String sendLogin(String username, String password) throws IOException {
        if(server.isClosed()) connect();
        
        printOutputStream.print("login\n");
        printOutputStream.print(username + "\n");
        printOutputStream.print(password + "\n");
        printOutputStream.flush();
        
        return inputStream.readLine();
    }
    
    public String sendRegister(String username, String password) throws IOException {
        printOutputStream.print("register\n");
        printOutputStream.print(username + "\n");
        printOutputStream.print(password + "\n");
        printOutputStream.flush();
        
        return inputStream.readLine();
    }
    
    //Stop data and command connection with the server
    //Also send the "stop" command to notify the server the user has disconnected
    public void stop() throws IOException {
        printOutputStream.print("stop\n");
        printOutputStream.flush();
        printOutputStream.close();
        
        if(dataConnection != null && !dataConnection.isClosed()) {
            dataConnection.close();
        }
        
        running = false;
        server.close();
    }
    
    //Read a line from an InputStream
    public static String readLine(InputStream inputStream) throws IOException {
        StringBuilder filename = new StringBuilder();
        int lastByte = 0;
        while((lastByte = inputStream.read()) != -1) {
            char c = ((char) lastByte);
            if(c == '\n') break;
            filename.append(c);
        }
        
        return filename.toString();
    }
    
    
}
