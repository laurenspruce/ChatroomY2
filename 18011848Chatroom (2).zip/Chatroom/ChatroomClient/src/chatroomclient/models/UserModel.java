package chatroomclient.models;

public class UserModel {
    
    public String username;

    public UserModel(String username) {
        this.username = username;
    }
    
    @Override
    public String toString() {
        return username;
    }

    
}
