package chatroomclient.models;

public class Chatroom {
    
    public String chatroomName;
    public Chatroom(String chatroomName) {
        this.chatroomName = chatroomName;
    }
    
    @Override
    public String toString() {
        return this.chatroomName;
    }
    
}
