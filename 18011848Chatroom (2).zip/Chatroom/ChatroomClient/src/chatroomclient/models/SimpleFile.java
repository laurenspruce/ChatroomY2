package chatroomclient.models;

import java.io.File;

public class SimpleFile{

    public File file;
    public SimpleFile(File file) {
        this.file = file;
    }
    
    @Override
    public String toString() {
        return file.getName();
    }
}
