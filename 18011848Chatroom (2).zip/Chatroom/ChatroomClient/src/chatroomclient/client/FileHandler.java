package chatroomclient.client;

import chatroomclient.interfaces.EventCallback;
import chatroomclient.ui.MainWindow;
import java.io.BufferedOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.logging.Level;
import java.util.logging.Logger;

public class FileHandler {
    
    private final InputStream inputStream;
    private final String outputDir;
    private final EventCallback eventCallback;

    public FileHandler(InputStream inputStream, String outputDir, EventCallback eventCallback) {
        this.inputStream = inputStream;
        this.outputDir = outputDir;
        this.eventCallback = eventCallback;
    }
    
    public void start() {
        try {
            
            //Read filename
            int lastByte = 0;
            StringBuilder filename = new StringBuilder();
            
            while((lastByte = inputStream.read()) != -1) {
                char c = ((char) lastByte);
                if(c == '\n') break;
                filename.append(c);
            }
            
            //Read filesize
            StringBuilder fileSizeBuilder = new StringBuilder();
            while((lastByte = inputStream.read()) != -1) {
                char c = ((char) lastByte);
                if(c == '\n') break;
                fileSizeBuilder.append(c);
            }
            
            long fileSize = Long.parseLong(fileSizeBuilder.toString());
            
            //Fire "file received" event
            if(this.eventCallback != null) {
                eventCallback.onFileReceived(filename.toString());
            }
            
            //Save file to disk
            FileOutputStream fos = new FileOutputStream(outputDir + MainWindow.username + "_" + filename);
            BufferedOutputStream bos = new BufferedOutputStream(fos);

            //Read file chunks into contents array 
            byte[] contents = null;
            int bytesRead = 0;
            long current = 0;

            while(current < fileSize){
                int size = 10240;
                if(fileSize - current >= size)
                    current += size;
                else{
                    size = (int)(fileSize - current);
                    current = fileSize;
                }
                
                contents = new byte[size];
                
                //Write bytes to file
                bytesRead = inputStream.read(contents, 0, size);
                bos.write(contents, 0, bytesRead);
            }
            
            //Close socket and streams
            bos.flush();
            bos.close();
            fos.close();
        } catch (IOException ex) {
            Logger.getLogger(FileHandler.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
}
