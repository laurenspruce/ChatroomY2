package chatroomclient.client;

import chatroomclient.interfaces.EventCallback;
import java.io.IOException;
import java.io.InputStream;
import java.util.logging.Level;
import java.util.logging.Logger;

public class MessageHandler{
    
    private final InputStream inputStream;
    private final EventCallback eventCallback;

    public MessageHandler(InputStream inputStream, EventCallback eventCallback) {
        this.inputStream = inputStream;
        this.eventCallback = eventCallback;
    }
    
    public void start() {
        try {
            
            //Read message until \nEND\n is received
            StringBuilder message = new StringBuilder();
            int lastByte = 0;
            while((lastByte = inputStream.read()) != -1) {
                char c = ((char) lastByte);
                message.append(c);

                if(message.lastIndexOf("\nEND\n") >= 0) break;
            }

            //Notify the message
            String finalMessage = message.toString();
            if(eventCallback != null) {
                eventCallback.onMessageReceived(finalMessage.substring(0, finalMessage.length() - 5));
            }
            
        } catch (IOException ex) {
            Logger.getLogger(MessageHandler.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
}
