package chatroomclient.client;

import chatroomclient.interfaces.EventCallback;
import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;

public class FileUpload {
    
    private Socket socket;
    private File file;
    private EventCallback callback;
    private String command;

    public FileUpload(Socket socket,
            File file,
            EventCallback callback) {
        this.socket = socket;
        this.file = file;
        this.callback = callback;
    }
    
    public FileUpload withCommand(String command) {
        this.command = command;
        return this;
    }
    
    
    public void start() {
        try {
            FileInputStream fis = new FileInputStream(file);
            BufferedInputStream bis = new BufferedInputStream(fis);

            //Get socket's output stream
            OutputStream os = socket.getOutputStream();
            os.write((command + "\n").getBytes());
            os.flush();
            os.write((file.getName() + "\n").getBytes());
            

            //Read file bytes into contents array
            byte[] contents;
            long fileLength = file.length();
            os.write((fileLength + "\n").getBytes());
            long current = 0;

            while(current < fileLength){
                int size = 10240;
                if(fileLength - current >= size)
                    current += size;
                else{
                    size = (int)(fileLength - current);
                    current = fileLength;
                }
                contents = new byte[size];
                
                //Read from file
                bis.read(contents, 0, size);
                
                //Write to socket
                os.write(contents);

                //Notify upload progress
                if(callback != null) {
                    callback.fileUploadProgress((current*100)/fileLength);
                }
            }

            //Close connection with input file
            os.flush();
            bis.close();
        } catch (IOException ex) {
            Logger.getLogger(FileUpload.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
